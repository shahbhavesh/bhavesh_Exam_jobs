package com.qaagility.javaee;

public class Calculator {

  public int add() {
    return 3 + 6;
  
  }
  public int add(int a, int b){
    return a + b;
  }
  
}
